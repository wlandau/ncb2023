my_packages <- c("tidyverse","plyr","glue","ggplot2","readxl","qdapRegex",              # Specify your packages
                 "stringr","lme4","lmerTest","rstan","brms","shinythemes",
                 "shinystan","mcmcplots","bayesplot","ggmcmc","tidybayes",
                 "broom","broom.mixed","broomExtra","captioner",
                 "kableExtra","DT")
not_installed <- my_packages[!(my_packages %in% installed.packages()[ , "Package"])]    # Extract not installed packages
if(length(not_installed)) install.packages(not_installed)                               # Install not installed packages

#Configuring and installing R-JAGS packages
Sys.setenv(PKG_CONFIG_PATH = "/opt/R/JAGS-4.3.0/lib/pkgconfig")
install.packages("rjags")
install.packages("runjags")
install.packages("R2jags")


