# Set seed
set.seed(20071978)
#Simulation Dataset
## Storage Conditions:
Cond<-c("5°C","25°C/60%RH","30°C/75%RH","40°C/75%RH","50°C")
##Number of batches
n <- 9
Batch <- 1:n
##Number of Vessels:
v <- 6
Vessel <- 1:v
##Time (Days):
Time <- c(0,3,6,9,12,18)
## Fixed effects:
Coefs <- c(91.86646,-0.11019,0.02614,0.11012,0.33017,0.59849) 
SE    <- c(0.5537,0.003753,0.02960,0.02960,0.07438,0.18197)
## Variance Components (SE): 
VarComp <- c(1.7300,0.9774,1.7390)
## Generate Data:      
datA <- expand.grid(Condition=Cond,Stabtime=Time,Batch=Batch,Vessel=Vessel)|> 
        arrange(Condition,Stabtime,Batch,Vessel) |> 
        mutate(Coef = ifelse(Condition==Cond[1],Coefs[2],
                       ifelse(Condition==Cond[2],Coefs[3],
                        ifelse(Condition==Cond[3],Coefs[4],
                        ifelse(Condition==Cond[4],Coefs[5],Coefs[5])))),
               Ser = ifelse(Condition==Cond[1],SE[2],
                        ifelse(Condition==Cond[2],SE[3],
                          ifelse(Condition==Cond[3],SE[4],
                            ifelse(Condition==Cond[4],SE[5],SE[5])))), 
               Int = Coefs[1],SeI=SE[1])|> 
        filter((Condition == Cond[1] & Stabtime %in% c(3,6,12))|
               (Condition == Cond[2])|
               (Condition == Cond[3] & Stabtime %in% c(3,6,9,12,18))|
               (Condition == Cond[4] & Stabtime %in% c(3,6))|
               (Condition == Cond[5] & Stabtime == 3)) |> 
        mutate(RunID = cumsum(!duplicated(cbind(Batch,Condition,Stabtime))))
  
### Random batch intercepts:
b <- rnorm(n,VarComp[1])  
### Random Run intercepts
r <- rep(rnorm(n=( dim(datA)[1]/v),mean=0,sd=VarComp[2]),each=v)
### Residual error  
e <- rnorm(n=( dim(datA)[1]),mean=0,sd=VarComp[3])
### Final analysis data:
# simdata <- cbind(datA,r,e) |> 
#            mutate(Result=rnorm(n=1,mean=Int,sd=SeI)+b[Batch]+
#                          rnorm(n=1,mean=Coef,sd=Ser)+r+e) |> 
#            mutate(Batch=as.factor(Batch),RunID=as.factor(RunID)) |> 
#            select(Condition,Stabtime,Batch,Vessel,Result)
simdata <- cbind(datA,r,e) |> 
  mutate(Result=rnorm(n=1,mean=Int,sd=0)+b[Batch]+
           rnorm(n=1,mean=Coef,sd=0)+r+e) |> 
  mutate(Batch=as.factor(Batch),RunID=as.factor(RunID)) |> 
  select(Condition,Stabtime,Batch,Vessel,Result)
### Save final data set:
# saveRDS(simdata, "Data/simdata.rds")
# read brms object:
# simdata <- readRDS("Data/simdata.rds")